Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
base = fso.GetParentFolderName(WScript.ScriptFullName)
shell.CurrentDirectory = base

envFile = base & "\.env"
configured = False
If fso.FileExists(envFile) Then
    Set f = fso.OpenTextFile(envFile, 1, False)
    content = f.ReadAll
    f.Close
    If InStr(content, "DB_SETUP_VERSION=2") > 0 Then configured = True
End If

If configured Then
    shell.Run Chr(34) & base & "\run_windows.bat" & Chr(34), 0, False
Else
    MsgBox "ITSM chua duoc cai dat. Hay chay bo Setup ITSM.", 48, "ITSM"
End If
