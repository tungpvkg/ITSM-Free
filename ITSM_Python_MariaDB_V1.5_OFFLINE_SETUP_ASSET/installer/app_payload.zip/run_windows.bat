@echo off
setlocal EnableExtensions
cd /d "%~dp0"
chcp 65001 >nul 2>&1
title ITSM - SERVER

if not exist ".env" (
    echo [ERROR] ITSM has not been installed yet.
    echo Run INSTALL_WINDOWS.bat first.
    pause
    exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
    echo [ERROR] Python virtual environment is missing.
    echo Run INSTALL_WINDOWS.bat again.
    pause
    exit /b 1
)

findstr /B /C:"DB_SETUP_VERSION=2" ".env" >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Database configuration is incomplete.
    echo Run RECONFIGURE_DATABASE.bat.
    pause
    exit /b 1
)

".venv\Scripts\python.exe" setup_db.py
if errorlevel 1 (
    echo [ERROR] Cannot connect to the ITSM database.
    echo Run RECONFIGURE_DATABASE.bat.
    pause
    exit /b 1
)

echo ITSM is starting at http://127.0.0.1:8088
start "" "http://127.0.0.1:8088"
".venv\Scripts\python.exe" server.py

if errorlevel 1 (
    echo.
    echo [ERROR] ITSM server stopped with an error.
    pause
)
endlocal
