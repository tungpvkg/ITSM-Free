from __future__ import annotations

import io
import os
import threading
import webbrowser
from collections import Counter
from datetime import datetime, timedelta
from functools import wraps

from flask import Flask, flash, redirect, render_template, request, send_file, session, url_for
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from sqlalchemy import func, or_

from config import Config
from models import db, User, Category, Ticket, TicketComment, AuditLog, AppSetting, Asset, AssetHistory

app = Flask(__name__)
app.config.from_object(Config)
db.init_app(app)

ROLE_LABELS = {'admin': 'Admin', 'technical': 'Technical', 'user': 'User'}
STATUS_LABELS = {
    'new': 'Mới', 'assigned': 'Đã phân công', 'in_progress': 'Đang xử lý',
    'waiting_user': 'Chờ người dùng', 'resolved': 'Đã hoàn thành', 'closed': 'Đã đóng'
}
PRIORITY_LABELS = {'low': 'Thấp', 'medium': 'Trung bình', 'high': 'Cao', 'critical': 'Khẩn cấp'}
ASSET_STATUS_LABELS = {
    'in_stock': 'Trong kho', 'in_use': 'Đang sử dụng', 'repair': 'Đang sửa',
    'broken': 'Hỏng', 'retired': 'Ngừng sử dụng', 'disposed': 'Đã thanh lý'
}
ASSET_CONDITION_LABELS = {'good': 'Tốt', 'fair': 'Trung bình', 'weak': 'Yếu', 'broken': 'Hỏng'}


def current_user():
    uid = session.get('user_id')
    if not uid:
        return None
    return db.session.get(User, uid)


@app.context_processor
def inject_globals():
    return {
        'me': current_user(),
        'ROLE_LABELS': ROLE_LABELS,
        'STATUS_LABELS': STATUS_LABELS,
        'PRIORITY_LABELS': PRIORITY_LABELS,
        'ASSET_STATUS_LABELS': ASSET_STATUS_LABELS,
        'ASSET_CONDITION_LABELS': ASSET_CONDITION_LABELS,
        'company_name': get_setting('company_name', 'IT Service Management'),
        'auto_close_minutes': get_auto_close_minutes(),
    }


def get_setting(key, default=''):
    try:
        row = AppSetting.query.filter_by(key=key).first()
        return row.value if row else default
    except Exception:
        return default


def get_auto_close_minutes():
    try:
        value = int(get_setting('auto_close_minutes', '30'))
    except (TypeError, ValueError):
        value = 30
    return max(1, min(value, 10080))


def auto_close_resolved_tickets():
    """Đóng các ticket đã hoàn thành quá thời gian cấu hình.

    Hàm này được worker nền gọi định kỳ. Không dùng session HTTP nên audit log
    được ghi trực tiếp với user_id=None.
    """
    minutes = get_auto_close_minutes()
    threshold = datetime.now() - timedelta(minutes=minutes)
    rows = Ticket.query.filter(
        Ticket.status == 'resolved',
        Ticket.resolved_at.isnot(None),
        Ticket.resolved_at <= threshold,
    ).all()
    if not rows:
        return 0
    now = datetime.now()
    for t in rows:
        t.status = 'closed'
        t.closed_at = now
        db.session.add(AuditLog(
            user_id=None, action='auto_close_ticket', entity_type='ticket',
            entity_id=str(t.id), detail=f'Tự động đóng {t.code} sau {minutes} phút ở trạng thái Đã hoàn thành'
        ))
    db.session.commit()
    return len(rows)


def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not current_user():
            return redirect(url_for('login'))
        return fn(*args, **kwargs)
    return wrapper


def roles_required(*roles):
    def deco(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            me = current_user()
            if not me:
                return redirect(url_for('login'))
            if me.role not in roles:
                flash('Bạn không có quyền truy cập chức năng này.', 'danger')
                return redirect(url_for('home'))
            return fn(*args, **kwargs)
        return wrapper
    return deco


def audit(action, entity_type, entity_id='', detail=''):
    me = current_user()
    db.session.add(AuditLog(
        user_id=me.id if me else None,
        action=action,
        entity_type=entity_type,
        entity_id=str(entity_id or ''),
        detail=detail,
    ))


def ticket_code(ticket_id: int) -> str:
    return f"IT-{datetime.now():%Y%m}-{ticket_id:05d}"


@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user():
        return redirect(url_for('home'))
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        user = User.query.filter(func.lower(User.username) == username.lower()).first()
        if not user or not user.is_active or not user.check_password(password):
            flash('Sai tài khoản/mật khẩu hoặc tài khoản đã bị khóa.', 'danger')
            return render_template('login.html')
        session['user_id'] = user.id
        audit('login', 'user', user.id, f'{user.username} đăng nhập')
        db.session.commit()
        return redirect(url_for('home'))
    return render_template('login.html')


@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))


@app.route('/')
@login_required
def home():
    me = current_user()
    if me.role == 'user':
        return redirect(url_for('user_dashboard'))
    return redirect(url_for('staff_dashboard'))


@app.route('/my')
@roles_required('user')
def user_dashboard():
    me = current_user()
    tickets = Ticket.query.filter_by(requester_id=me.id).order_by(Ticket.requested_at.desc()).all()
    counts = Counter(t.status for t in tickets)
    return render_template('user_dashboard.html', tickets=tickets, counts=counts)


@app.route('/ticket/new', methods=['GET', 'POST'])
@login_required
def create_ticket():
    me = current_user()
    categories = Category.query.filter_by(is_active=True).order_by(Category.name).all()
    requester_users = []
    if me.role in ('admin', 'technical'):
        requester_users = User.query.filter_by(role='user', is_active=True).order_by(User.full_name).all()

    if request.method == 'POST':
        category_id = request.form.get('category_id', type=int)
        category = db.session.get(Category, category_id)
        subject = request.form.get('subject', '').strip()
        description = request.form.get('description', '').strip()
        priority = request.form.get('priority', 'medium')

        requester_id = me.id
        requester_name = ''
        on_behalf = me.role in ('admin', 'technical') and request.form.get('on_behalf') == '1'
        if on_behalf:
            existing_user_id = request.form.get('requester_user_id', type=int)
            external_name = request.form.get('requester_name', '').strip()
            existing_user = db.session.get(User, existing_user_id) if existing_user_id else None
            if existing_user and existing_user.role == 'user' and existing_user.is_active:
                requester_id = existing_user.id
            elif external_name:
                requester_id = None
                requester_name = external_name[:150]
            else:
                flash('Khi tạo yêu cầu hộ, hãy chọn User trong hệ thống hoặc nhập tên người yêu cầu.', 'danger')
                return render_template('create_ticket.html', categories=categories, requester_users=requester_users)

        if not category or not subject or not description or priority not in PRIORITY_LABELS:
            flash('Vui lòng nhập đầy đủ thông tin yêu cầu.', 'danger')
            return render_template('create_ticket.html', categories=categories, requester_users=requester_users)

        t = Ticket(
            code='PENDING', requester_id=requester_id, requester_name=requester_name,
            category_id=category.id, subject=subject, description=description,
            priority=priority, requested_at=datetime.now(), status='new'
        )
        db.session.add(t)
        db.session.flush()
        t.code = ticket_code(t.id)
        if on_behalf:
            audit('create_ticket_on_behalf', 'ticket', t.id, f'Tạo hộ {t.requester_display_name}: {t.code}')
        else:
            audit('create_ticket', 'ticket', t.id, f'Tạo {t.code}')
        db.session.commit()
        flash(f'Đã gửi yêu cầu {t.code}.', 'success')
        return redirect(url_for('ticket_detail', ticket_id=t.id))

    return render_template('create_ticket.html', categories=categories, requester_users=requester_users)


@app.route('/ticket/<int:ticket_id>', methods=['GET', 'POST'])
@login_required
def ticket_detail(ticket_id):
    t = db.session.get(Ticket, ticket_id)
    if not t:
        flash('Không tìm thấy ticket.', 'danger')
        return redirect(url_for('home'))
    me = current_user()
    if me.role == 'user' and t.requester_id != me.id:
        flash('Bạn không có quyền xem ticket này.', 'danger')
        return redirect(url_for('home'))

    if request.method == 'POST':
        content = request.form.get('content', '').strip()
        is_internal = bool(request.form.get('is_internal')) and me.role in ('admin', 'technical')
        if content:
            db.session.add(TicketComment(ticket_id=t.id, user_id=me.id, content=content, is_internal=is_internal))
            if me.role in ('admin', 'technical') and not t.first_response_at:
                t.first_response_at = datetime.now()
            audit('comment', 'ticket', t.id, 'Thêm ghi chú nội bộ' if is_internal else 'Thêm phản hồi')
            db.session.commit()
            flash('Đã thêm nội dung trao đổi.', 'success')
        return redirect(url_for('ticket_detail', ticket_id=t.id))

    comments = t.comments
    if me.role == 'user':
        comments = [c for c in comments if not c.is_internal]
    techs = User.query.filter(User.role.in_(['technical', 'admin']), User.is_active == True).order_by(User.full_name).all()
    return render_template('ticket_detail.html', ticket=t, comments=comments, techs=techs)


@app.post('/ticket/<int:ticket_id>/update')
@roles_required('admin', 'technical')
def update_ticket(ticket_id):
    t = db.session.get(Ticket, ticket_id)
    if not t:
        flash('Không tìm thấy ticket.', 'danger')
        return redirect(url_for('staff_dashboard'))
    me = current_user()
    old_status = t.status
    status = request.form.get('status', t.status)
    priority = request.form.get('priority', t.priority)
    assignee_id = request.form.get('assignee_id', type=int)
    resolution = request.form.get('resolution', '').strip()

    if status not in STATUS_LABELS or priority not in PRIORITY_LABELS:
        flash('Dữ liệu trạng thái/ưu tiên không hợp lệ.', 'danger')
        return redirect(url_for('ticket_detail', ticket_id=t.id))

    if me.role == 'technical':
        if t.assignee_id not in (None, me.id):
            flash('Ticket đang được phân công cho kỹ thuật viên khác.', 'danger')
            return redirect(url_for('ticket_detail', ticket_id=t.id))
        t.assignee_id = me.id
    else:
        if assignee_id:
            assignee = db.session.get(User, assignee_id)
            if assignee and assignee.role in ('technical', 'admin'):
                t.assignee_id = assignee.id
        elif request.form.get('clear_assignee') == '1':
            t.assignee_id = None

    t.status = status
    t.priority = priority
    if resolution:
        t.resolution = resolution
    if t.assignee_id and t.status == 'new':
        t.status = 'assigned'
    now = datetime.now()
    if t.status == 'resolved':
        if old_status != 'resolved':
            t.resolved_at = now
        t.closed_at = None
    elif t.status == 'closed':
        if not t.resolved_at:
            t.resolved_at = now
        if old_status != 'closed' or not t.closed_at:
            t.closed_at = now
    else:
        if old_status in ('resolved', 'closed'):
            t.resolved_at = None
            t.closed_at = None
    if not t.first_response_at:
        t.first_response_at = datetime.now()
    audit('update_ticket', 'ticket', t.id, f'{old_status} -> {t.status}; assignee={t.assignee_id}')
    db.session.commit()
    flash('Đã cập nhật ticket.', 'success')
    return redirect(url_for('ticket_detail', ticket_id=t.id))


@app.post('/ticket/<int:ticket_id>/accept')
@roles_required('admin', 'technical')
def accept_ticket(ticket_id):
    t = db.session.get(Ticket, ticket_id)
    me = current_user()
    if not t:
        flash('Không tìm thấy ticket.', 'danger')
    elif t.assignee_id and t.assignee_id != me.id and me.role != 'admin':
        flash('Ticket đã được kỹ thuật viên khác tiếp nhận.', 'danger')
    else:
        t.assignee_id = me.id
        if t.status == 'new':
            t.status = 'assigned'
        if not t.first_response_at:
            t.first_response_at = datetime.now()
        audit('accept_ticket', 'ticket', t.id, f'{me.username} tiếp nhận')
        db.session.commit()
        flash('Đã tiếp nhận ticket.', 'success')
    return redirect(url_for('ticket_detail', ticket_id=ticket_id))


@app.route('/staff')
@roles_required('admin', 'technical')
def staff_dashboard():
    me = current_user()
    base = Ticket.query
    total = base.count()
    new_count = base.filter(Ticket.status == 'new').count()
    active_count = base.filter(Ticket.status.in_(['assigned', 'in_progress', 'waiting_user'])).count()
    overdue = [t for t in base.filter(~Ticket.status.in_(['resolved', 'closed'])).all() if not t.is_sla_met]
    my_count = base.filter(Ticket.assignee_id == me.id, ~Ticket.status.in_(['resolved', 'closed'])).count()
    recent = base.order_by(Ticket.requested_at.desc()).limit(12).all()
    return render_template('staff_dashboard.html', total=total, new_count=new_count,
                           active_count=active_count, overdue_count=len(overdue), my_count=my_count,
                           tickets=recent)


@app.route('/staff/tickets')
@roles_required('admin', 'technical')
def staff_tickets():
    q = Ticket.query
    status = request.args.get('status', '')
    priority = request.args.get('priority', '')
    assignee = request.args.get('assignee', '')
    keyword = request.args.get('q', '').strip()
    if status in STATUS_LABELS:
        q = q.filter(Ticket.status == status)
    if priority in PRIORITY_LABELS:
        q = q.filter(Ticket.priority == priority)
    if assignee == 'unassigned':
        q = q.filter(Ticket.assignee_id.is_(None))
    elif assignee.isdigit():
        q = q.filter(Ticket.assignee_id == int(assignee))
    if keyword:
        like = f'%{keyword}%'
        q = q.outerjoin(User, Ticket.requester_id == User.id).filter(or_(
            Ticket.code.like(like), Ticket.subject.like(like),
            User.full_name.like(like), Ticket.requester_name.like(like)
        ))
    tickets = q.order_by(Ticket.requested_at.desc()).all()
    techs = User.query.filter(User.role.in_(['technical', 'admin']), User.is_active == True).order_by(User.full_name).all()
    return render_template('staff_tickets.html', tickets=tickets, techs=techs)



def parse_date_input(value):
    value = (value or '').strip()
    if not value:
        return None
    for fmt in ('%Y-%m-%d', '%d/%m/%Y'):
        try:
            return datetime.strptime(value, fmt).date()
        except ValueError:
            pass
    return None


def add_asset_history(asset, action, from_value='', to_value='', detail=''):
    me = current_user()
    db.session.add(AssetHistory(
        asset_id=asset.id,
        actor_id=me.id if me else None,
        action=action,
        from_value=str(from_value or '')[:255],
        to_value=str(to_value or '')[:255],
        detail=detail,
    ))


@app.route('/assets')
@roles_required('admin', 'technical')
def assets():
    q = Asset.query
    keyword = request.args.get('q', '').strip()
    asset_type = request.args.get('type', '').strip()
    status = request.args.get('status', '').strip()
    condition = request.args.get('condition', '').strip()
    if keyword:
        like = f'%{keyword}%'
        q = q.outerjoin(User, Asset.assigned_user_id == User.id).filter(or_(
            Asset.asset_code.like(like), Asset.name.like(like), Asset.asset_type.like(like),
            Asset.manufacturer.like(like), Asset.model.like(like), Asset.serial_number.like(like),
            Asset.company.like(like), Asset.department.like(like), Asset.location.like(like),
            Asset.ip_address.like(like), Asset.mac_address.like(like),
            Asset.assigned_to_name.like(like), User.full_name.like(like)
        ))
    if asset_type:
        q = q.filter(Asset.asset_type == asset_type)
    if status in ASSET_STATUS_LABELS:
        q = q.filter(Asset.status == status)
    if condition in ASSET_CONDITION_LABELS:
        q = q.filter(Asset.condition == condition)
    rows = q.order_by(Asset.asset_code).all()
    types = [r[0] for r in db.session.query(Asset.asset_type).distinct().order_by(Asset.asset_type).all() if r[0]]
    counts = {
        'total': Asset.query.count(),
        'in_use': Asset.query.filter_by(status='in_use').count(),
        'in_stock': Asset.query.filter_by(status='in_stock').count(),
        'problem': Asset.query.filter(or_(Asset.status.in_(['repair', 'broken']), Asset.condition.in_(['weak', 'broken']))).count(),
    }
    return render_template('assets.html', assets=rows, types=types, counts=counts)


@app.route('/assets/new', methods=['GET', 'POST'])
@app.route('/assets/<int:asset_id>/edit', methods=['GET', 'POST'])
@roles_required('admin', 'technical')
def asset_form(asset_id=None):
    row = db.session.get(Asset, asset_id) if asset_id else None
    users = User.query.filter_by(is_active=True).order_by(User.full_name).all()
    if request.method == 'POST':
        asset_code = request.form.get('asset_code', '').strip()
        name = request.form.get('name', '').strip()
        asset_type = request.form.get('asset_type', '').strip()
        status = request.form.get('status', 'in_stock')
        condition = request.form.get('condition', 'good')
        if not asset_code or not name or not asset_type:
            flash('Mã tài sản, tên tài sản và loại thiết bị là bắt buộc.', 'danger')
            return render_template('asset_form.html', asset=row, users=users)
        if status not in ASSET_STATUS_LABELS or condition not in ASSET_CONDITION_LABELS:
            flash('Trạng thái hoặc tình trạng tài sản không hợp lệ.', 'danger')
            return render_template('asset_form.html', asset=row, users=users)
        duplicate = Asset.query.filter(func.lower(Asset.asset_code) == asset_code.lower())
        if row:
            duplicate = duplicate.filter(Asset.id != row.id)
        if duplicate.first():
            flash('Mã tài sản đã tồn tại.', 'danger')
            return render_template('asset_form.html', asset=row, users=users)

        creating = row is None
        old_summary = '' if creating else f'{row.asset_code}; {row.status}; {row.assigned_display_name}'
        if creating:
            row = Asset(asset_code=asset_code, name=name, asset_type=asset_type)
            db.session.add(row)
            db.session.flush()

        row.asset_code = asset_code[:80]
        row.name = name[:180]
        row.asset_type = asset_type[:120]
        row.manufacturer = request.form.get('manufacturer', '').strip()[:120]
        row.model = request.form.get('model', '').strip()[:120]
        row.serial_number = request.form.get('serial_number', '').strip()[:150]
        row.company = request.form.get('company', '').strip()[:150]
        row.department = request.form.get('department', '').strip()[:150]
        row.location = request.form.get('location', '').strip()[:180]
        row.ip_address = request.form.get('ip_address', '').strip()[:64]
        row.mac_address = request.form.get('mac_address', '').strip()[:64]
        row.status = status
        row.condition = condition
        row.purchase_date = parse_date_input(request.form.get('purchase_date'))
        row.warranty_until = parse_date_input(request.form.get('warranty_until'))
        row.last_audit_date = parse_date_input(request.form.get('last_audit_date'))
        cost_raw = request.form.get('purchase_cost', '').replace(',', '').strip()
        try:
            row.purchase_cost = float(cost_raw) if cost_raw else None
        except ValueError:
            row.purchase_cost = None
        row.supplier = request.form.get('supplier', '').strip()[:180]
        row.note = request.form.get('note', '').strip()

        assigned_user_id = request.form.get('assigned_user_id', type=int)
        assigned_user = db.session.get(User, assigned_user_id) if assigned_user_id else None
        external_name = request.form.get('assigned_to_name', '').strip()[:150]
        old_assignee = row.assigned_display_name if not creating else 'Chưa cấp phát'
        if assigned_user:
            row.assigned_user_id = assigned_user.id
            row.assigned_to_name = ''
            row.assigned_at = row.assigned_at or datetime.now()
            if row.status == 'in_stock': row.status = 'in_use'
        elif external_name:
            row.assigned_user_id = None
            row.assigned_to_name = external_name
            row.assigned_at = row.assigned_at or datetime.now()
            if row.status == 'in_stock': row.status = 'in_use'
        elif request.form.get('clear_assignee') == '1' or creating:
            row.assigned_user_id = None
            row.assigned_to_name = ''
            row.assigned_at = None
            if row.status == 'in_use': row.status = 'in_stock'

        db.session.flush()
        action = 'create' if creating else 'update'
        new_summary = f'{row.asset_code}; {row.status}; {row.assigned_display_name}'
        add_asset_history(row, action, old_summary, new_summary, 'Tạo mới tài sản' if creating else 'Cập nhật thông tin tài sản')
        if old_assignee != row.assigned_display_name and not creating:
            add_asset_history(row, 'assignment', old_assignee, row.assigned_display_name, 'Thay đổi người sử dụng tài sản')
        audit(f'{action}_asset', 'asset', row.id, new_summary)
        db.session.commit()
        flash('Đã lưu tài sản CNTT.', 'success')
        return redirect(url_for('asset_detail', asset_id=row.id))
    return render_template('asset_form.html', asset=row, users=users)


@app.route('/assets/<int:asset_id>')
@roles_required('admin', 'technical')
def asset_detail(asset_id):
    row = db.session.get(Asset, asset_id)
    if not row:
        flash('Không tìm thấy tài sản.', 'danger')
        return redirect(url_for('assets'))
    users = User.query.filter_by(is_active=True).order_by(User.full_name).all()
    return render_template('asset_detail.html', asset=row, users=users)


@app.post('/assets/<int:asset_id>/assign')
@roles_required('admin', 'technical')
def asset_assign(asset_id):
    row = db.session.get(Asset, asset_id)
    if not row:
        flash('Không tìm thấy tài sản.', 'danger')
        return redirect(url_for('assets'))
    old = row.assigned_display_name
    user_id = request.form.get('assigned_user_id', type=int)
    user = db.session.get(User, user_id) if user_id else None
    external_name = request.form.get('assigned_to_name', '').strip()[:150]
    if not user and not external_name:
        flash('Hãy chọn tài khoản hoặc nhập tên người nhận tài sản.', 'danger')
        return redirect(url_for('asset_detail', asset_id=row.id))
    row.assigned_user_id = user.id if user else None
    row.assigned_to_name = '' if user else external_name
    row.assigned_at = datetime.now()
    row.status = 'in_use'
    if user and user.department:
        row.department = user.department
    add_asset_history(row, 'assign', old, row.assigned_display_name, request.form.get('detail', '').strip() or 'Cấp phát tài sản')
    audit('assign_asset', 'asset', row.id, f'{old} -> {row.assigned_display_name}')
    db.session.commit()
    flash('Đã cấp phát tài sản.', 'success')
    return redirect(url_for('asset_detail', asset_id=row.id))


@app.post('/assets/<int:asset_id>/return')
@roles_required('admin', 'technical')
def asset_return(asset_id):
    row = db.session.get(Asset, asset_id)
    if not row:
        flash('Không tìm thấy tài sản.', 'danger')
        return redirect(url_for('assets'))
    old = row.assigned_display_name
    row.assigned_user_id = None
    row.assigned_to_name = ''
    row.assigned_at = None
    row.status = 'in_stock'
    add_asset_history(row, 'return', old, 'Trong kho', request.form.get('detail', '').strip() or 'Thu hồi tài sản về kho')
    audit('return_asset', 'asset', row.id, f'{old} -> Trong kho')
    db.session.commit()
    flash('Đã thu hồi tài sản về kho.', 'success')
    return redirect(url_for('asset_detail', asset_id=row.id))


@app.post('/assets/<int:asset_id>/delete')
@roles_required('admin')
def asset_delete(asset_id):
    row = db.session.get(Asset, asset_id)
    if not row:
        flash('Không tìm thấy tài sản.', 'danger')
    else:
        code = row.asset_code
        AssetHistory.query.filter_by(asset_id=row.id).delete()
        audit('delete_asset', 'asset', row.id, code)
        db.session.delete(row)
        db.session.commit()
        flash(f'Đã xóa tài sản {code}.', 'success')
    return redirect(url_for('assets'))


@app.route('/assets/export.xlsx')
@roles_required('admin', 'technical')
def export_assets():
    rows = Asset.query.order_by(Asset.asset_code).all()
    wb = Workbook()
    ws = wb.active
    ws.title = 'Tai san CNTT'
    headers = ['Mã tài sản', 'Tên tài sản', 'Loại', 'Hãng', 'Model', 'Serial', 'Công ty', 'Phòng ban', 'Vị trí', 'IP', 'MAC', 'Trạng thái', 'Tình trạng', 'Người sử dụng', 'Ngày cấp phát', 'Ngày mua', 'Bảo hành đến', 'Giá trị', 'Nhà cung cấp', 'Ngày audit', 'Ghi chú']
    ws.append(headers)
    for cell in ws[1]:
        cell.font = Font(bold=True, color='FFFFFF')
        cell.fill = PatternFill('solid', fgColor='1F4E78')
        cell.alignment = Alignment(horizontal='center')
    for a in rows:
        ws.append([
            a.asset_code, a.name, a.asset_type, a.manufacturer, a.model, a.serial_number,
            a.company, a.department, a.location, a.ip_address, a.mac_address,
            ASSET_STATUS_LABELS.get(a.status, a.status), ASSET_CONDITION_LABELS.get(a.condition, a.condition),
            a.assigned_display_name if (a.assigned_user_id or a.assigned_to_name) else '',
            a.assigned_at.strftime('%d/%m/%Y %H:%M') if a.assigned_at else '',
            a.purchase_date.strftime('%d/%m/%Y') if a.purchase_date else '',
            a.warranty_until.strftime('%d/%m/%Y') if a.warranty_until else '',
            float(a.purchase_cost) if a.purchase_cost is not None else '', a.supplier,
            a.last_audit_date.strftime('%d/%m/%Y') if a.last_audit_date else '', a.note,
        ])
    widths = [15,28,18,18,18,20,22,20,24,16,18,16,16,24,20,14,14,16,24,14,42]
    from openpyxl.utils import get_column_letter
    for i, width in enumerate(widths, 1): ws.column_dimensions[get_column_letter(i)].width = width
    ws.freeze_panes = 'A2'; ws.auto_filter.ref = ws.dimensions
    output = io.BytesIO(); wb.save(output); output.seek(0)
    return send_file(output, as_attachment=True, download_name=f'ITSM_Assets_{datetime.now():%Y%m%d}.xlsx', mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')

@app.route('/admin/users')
@roles_required('admin')
def users():
    rows = User.query.order_by(User.role, User.username).all()
    return render_template('users.html', users=rows)


@app.route('/admin/users/new', methods=['GET', 'POST'])
@app.route('/admin/users/<int:user_id>/edit', methods=['GET', 'POST'])
@roles_required('admin')
def user_form(user_id=None):
    row = db.session.get(User, user_id) if user_id else None
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        full_name = request.form.get('full_name', '').strip()
        email = request.form.get('email', '').strip()
        department = request.form.get('department', '').strip()
        role = request.form.get('role', 'user')
        password = request.form.get('password', '')
        is_active = request.form.get('is_active') == '1'
        if role not in ROLE_LABELS or not username or not full_name:
            flash('Vui lòng nhập tên đăng nhập, họ tên và quyền hợp lệ.', 'danger')
            return render_template('user_form.html', user=row)
        duplicate = User.query.filter(func.lower(User.username) == username.lower())
        if row:
            duplicate = duplicate.filter(User.id != row.id)
        if duplicate.first():
            flash('Tên đăng nhập đã tồn tại.', 'danger')
            return render_template('user_form.html', user=row)
        if not row:
            if len(password) < 6:
                flash('Mật khẩu ban đầu tối thiểu 6 ký tự.', 'danger')
                return render_template('user_form.html', user=row)
            row = User(username=username, full_name=full_name)
            db.session.add(row)
        row.username = username
        row.full_name = full_name
        row.email = email
        row.department = department
        row.role = role
        row.is_active = is_active
        if password:
            row.set_password(password)
        audit('save_user', 'user', row.id or '', f'{username}; role={role}; active={is_active}')
        db.session.commit()
        flash('Đã lưu tài khoản.', 'success')
        return redirect(url_for('users'))
    return render_template('user_form.html', user=row)


@app.post('/admin/users/<int:user_id>/toggle')
@roles_required('admin')
def toggle_user(user_id):
    row = db.session.get(User, user_id)
    if row and row.id != current_user().id:
        row.is_active = not row.is_active
        audit('toggle_user', 'user', row.id, f'active={row.is_active}')
        db.session.commit()
        flash('Đã cập nhật trạng thái tài khoản.', 'success')
    return redirect(url_for('users'))


@app.post('/admin/users/<int:user_id>/delete')
@roles_required('admin')
def delete_user(user_id):
    row = db.session.get(User, user_id)
    if not row or row.id == current_user().id:
        flash('Không thể xóa tài khoản này.', 'danger')
    elif row.requested_tickets or row.assigned_tickets or row.assigned_assets or AssetHistory.query.filter_by(actor_id=row.id).first():
        flash('Tài khoản đã phát sinh ticket hoặc tài sản CNTT, hãy khóa tài khoản thay vì xóa.', 'danger')
    else:
        audit('delete_user', 'user', row.id, row.username)
        db.session.delete(row)
        db.session.commit()
        flash('Đã xóa tài khoản.', 'success')
    return redirect(url_for('users'))


def parse_report_range():
    end = datetime.now().replace(hour=23, minute=59, second=59, microsecond=0)
    start = (end - timedelta(days=29)).replace(hour=0, minute=0, second=0)
    s = request.args.get('from', '')
    e = request.args.get('to', '')
    try:
        if s:
            start = datetime.strptime(s, '%Y-%m-%d')
        if e:
            end = datetime.strptime(e, '%Y-%m-%d').replace(hour=23, minute=59, second=59)
    except ValueError:
        pass
    return start, end


def report_data(start, end):
    tickets = Ticket.query.filter(Ticket.requested_at.between(start, end)).order_by(Ticket.requested_at).all()
    total = len(tickets)
    resolved = [t for t in tickets if t.resolved_at]
    sla_met = [t for t in resolved if t.is_sla_met]
    resolution_values = [t.resolution_hours for t in resolved if t.resolution_hours is not None]
    avg_resolution = round(sum(resolution_values) / len(resolution_values), 2) if resolution_values else 0
    sla_rate = round(len(sla_met) * 100 / len(resolved), 1) if resolved else 0
    first_response_values = [round((t.first_response_at - t.requested_at).total_seconds()/3600, 2)
                             for t in tickets if t.first_response_at]
    avg_first_response = round(sum(first_response_values)/len(first_response_values), 2) if first_response_values else 0

    by_status = Counter(STATUS_LABELS[t.status] for t in tickets)
    by_priority = Counter(PRIORITY_LABELS[t.priority] for t in tickets)
    by_category = Counter(t.category.name for t in tickets)
    by_tech = Counter((t.assignee.full_name if t.assignee else 'Chưa phân công') for t in tickets)
    by_day = Counter(t.requested_at.strftime('%d/%m') for t in tickets)
    return {
        'tickets': tickets, 'total': total, 'resolved_count': len(resolved), 'sla_rate': sla_rate,
        'avg_resolution': avg_resolution, 'avg_first_response': avg_first_response,
        'by_status': by_status, 'by_priority': by_priority, 'by_category': by_category,
        'by_tech': by_tech, 'by_day': by_day,
    }


@app.route('/reports')
@roles_required('admin', 'technical')
def reports():
    start, end = parse_report_range()
    data = report_data(start, end)
    return render_template('reports.html', start=start, end=end, **data)


@app.route('/reports/export.xlsx')
@roles_required('admin', 'technical')
def export_reports():
    start, end = parse_report_range()
    data = report_data(start, end)
    wb = Workbook()
    ws = wb.active
    ws.title = 'Ticket Detail'
    headers = ['Mã ticket', 'Ngày yêu cầu', 'Người yêu cầu', 'Bộ phận', 'Nhóm sự cố', 'Tiêu đề', 'Ưu tiên', 'Trạng thái', 'Kỹ thuật viên', 'Ngày xử lý', 'Giờ xử lý', 'Đạt SLA', 'Kết quả xử lý']
    ws.append(headers)
    for cell in ws[1]:
        cell.font = Font(bold=True, color='FFFFFF')
        cell.fill = PatternFill('solid', fgColor='1F4E78')
        cell.alignment = Alignment(horizontal='center')
    for t in data['tickets']:
        ws.append([
            t.code, t.requested_at.strftime('%d/%m/%Y %H:%M'), t.requester_display_name,
            t.requester_department, t.category.name, t.subject, PRIORITY_LABELS[t.priority],
            STATUS_LABELS[t.status], t.assignee.full_name if t.assignee else '',
            t.resolved_at.strftime('%d/%m/%Y %H:%M') if t.resolved_at else '',
            t.resolution_hours if t.resolution_hours is not None else '',
            'Có' if (t.resolved_at and t.is_sla_met) else ('Không' if t.resolved_at else ''),
            t.resolution,
        ])
    widths = [16,20,24,20,30,42,14,18,24,20,12,12,50]
    for i, width in enumerate(widths, 1):
        ws.column_dimensions[chr(64+i) if i <= 26 else 'A'].width = width
    ws.freeze_panes = 'A2'
    ws.auto_filter.ref = ws.dimensions

    summary = wb.create_sheet('Summary')
    summary.append(['BÁO CÁO ITSM', f'{start:%d/%m/%Y} - {end:%d/%m/%Y}'])
    summary.append(['Tổng ticket', data['total']])
    summary.append(['Đã hoàn thành', data['resolved_count']])
    summary.append(['Tỷ lệ đạt SLA (%)', data['sla_rate']])
    summary.append(['TG xử lý TB (giờ)', data['avg_resolution']])
    summary.append(['TG phản hồi đầu TB (giờ)', data['avg_first_response']])
    summary.append([])
    summary.append(['Theo trạng thái', 'Số lượng'])
    for k, v in data['by_status'].items(): summary.append([k, v])
    summary.append([])
    summary.append(['Theo kỹ thuật viên', 'Số lượng'])
    for k, v in data['by_tech'].items(): summary.append([k, v])
    summary.column_dimensions['A'].width = 32
    summary.column_dimensions['B'].width = 22
    for cell in summary[1]: cell.font = Font(bold=True, size=14)

    output = io.BytesIO()
    wb.save(output)
    output.seek(0)
    filename = f'ITSM_Report_{start:%Y%m%d}_{end:%Y%m%d}.xlsx'
    return send_file(output, as_attachment=True, download_name=filename, mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')


@app.route('/admin/settings', methods=['GET', 'POST'])
@roles_required('admin')
def settings():
    if request.method == 'POST':
        auto_close_raw = request.form.get('auto_close_minutes', '30').strip()
        try:
            auto_close_value = int(auto_close_raw)
        except ValueError:
            auto_close_value = 30
        if not 1 <= auto_close_value <= 10080:
            flash('Thời gian tự động đóng phải từ 1 đến 10080 phút (7 ngày).', 'danger')
            return redirect(url_for('settings'))

        values = {
            'company_name': request.form.get('company_name', '').strip(),
            'support_name': request.form.get('support_name', '').strip(),
            'default_sla_hours': request.form.get('default_sla_hours', '8').strip(),
            'auto_close_minutes': str(auto_close_value),
        }
        for key, value in values.items():
            row = AppSetting.query.filter_by(key=key).first()
            if not row:
                row = AppSetting(key=key)
                db.session.add(row)
            row.value = value
        audit('save_settings', 'settings', '', f'Cập nhật cấu hình; auto_close={auto_close_value} phút')
        db.session.commit()
        flash('Đã lưu cấu hình.', 'success')
        return redirect(url_for('settings'))
    settings_data = {r.key: r.value for r in AppSetting.query.all()}
    categories = Category.query.order_by(Category.name).all()
    return render_template('settings.html', settings=settings_data, categories=categories)


@app.post('/admin/categories/save')
@roles_required('admin')
def save_category():
    category_id = request.form.get('category_id', type=int)
    name = request.form.get('name', '').strip()
    sla_hours = request.form.get('sla_hours', type=int) or 8
    if not name:
        flash('Tên nhóm hỗ trợ không được để trống.', 'danger')
        return redirect(url_for('settings'))
    row = db.session.get(Category, category_id) if category_id else Category()
    if not row.id:
        db.session.add(row)
    row.name = name
    row.sla_hours = max(1, sla_hours)
    row.is_active = request.form.get('is_active') == '1'
    db.session.commit()
    flash('Đã lưu nhóm hỗ trợ.', 'success')
    return redirect(url_for('settings'))


@app.errorhandler(404)
def not_found(_):
    return render_template('404.html'), 404


if __name__ == '__main__':
    port = Config.APP_PORT
    def open_browser():
        try:
            webbrowser.open(f'http://127.0.0.1:{port}')
        except Exception:
            pass
    threading.Timer(1.2, open_browser).start()
    app.run(host=Config.APP_HOST, port=port, debug=Config.APP_DEBUG)
