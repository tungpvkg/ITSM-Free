import threading
import time
import webbrowser

from waitress import serve

from app import app, auto_close_resolved_tickets
from config import Config
from models import db


def open_browser():
    try:
        webbrowser.open(f'http://127.0.0.1:{Config.APP_PORT}')
    except Exception:
        pass


def auto_close_worker():
    # Kiểm tra mỗi 30 giây để trạng thái được cập nhật gần sát thời gian cấu hình.
    while True:
        try:
            with app.app_context():
                closed = auto_close_resolved_tickets()
                if closed:
                    print(f'[AUTO CLOSE] Đã tự động đóng {closed} ticket.')
        except Exception as exc:
            try:
                with app.app_context():
                    db.session.rollback()
            except Exception:
                pass
            print(f'[AUTO CLOSE] Lỗi: {exc}')
        time.sleep(30)


if __name__ == '__main__':
    threading.Timer(1.2, open_browser).start()
    threading.Thread(target=auto_close_worker, daemon=True, name='itsm-auto-close').start()
    print(f'ITSM running: http://127.0.0.1:{Config.APP_PORT}')
    print('Auto-close worker: enabled')
    serve(app, host=Config.APP_HOST, port=Config.APP_PORT, threads=8)
