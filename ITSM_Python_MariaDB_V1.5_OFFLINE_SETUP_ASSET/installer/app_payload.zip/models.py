from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash


db = SQLAlchemy()


class User(db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False, index=True)
    full_name = db.Column(db.String(150), nullable=False)
    email = db.Column(db.String(150), default='')
    department = db.Column(db.String(150), default='')
    role = db.Column(db.Enum('admin', 'technical', 'user'), nullable=False, default='user', index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    is_active = db.Column(db.Boolean, nullable=False, default=True)
    created_at = db.Column(db.DateTime, default=datetime.now, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now, nullable=False)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


class Category(db.Model):
    __tablename__ = 'categories'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), unique=True, nullable=False)
    sla_hours = db.Column(db.Integer, nullable=False, default=8)
    is_active = db.Column(db.Boolean, nullable=False, default=True)


class Ticket(db.Model):
    __tablename__ = 'tickets'
    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(30), unique=True, nullable=False, index=True)
    # requester_id có thể rỗng khi Technical/Admin tạo hộ người dùng ngoài hệ thống.
    requester_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True, index=True)
    requester_name = db.Column(db.String(150), nullable=True, default='')
    assignee_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True, index=True)
    category_id = db.Column(db.Integer, db.ForeignKey('categories.id'), nullable=False)
    subject = db.Column(db.String(250), nullable=False)
    description = db.Column(db.Text, nullable=False)
    priority = db.Column(db.Enum('low', 'medium', 'high', 'critical'), nullable=False, default='medium', index=True)
    status = db.Column(db.Enum('new', 'assigned', 'in_progress', 'waiting_user', 'resolved', 'closed'), nullable=False, default='new', index=True)
    resolution = db.Column(db.Text, default='')
    requested_at = db.Column(db.DateTime, default=datetime.now, nullable=False, index=True)
    first_response_at = db.Column(db.DateTime, nullable=True)
    resolved_at = db.Column(db.DateTime, nullable=True)
    closed_at = db.Column(db.DateTime, nullable=True)
    updated_at = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now, nullable=False)

    requester = db.relationship('User', foreign_keys=[requester_id], backref='requested_tickets')
    assignee = db.relationship('User', foreign_keys=[assignee_id], backref='assigned_tickets')
    category = db.relationship('Category', backref='tickets')

    @property
    def requester_display_name(self):
        if self.requester:
            return self.requester.full_name
        return (self.requester_name or '').strip() or 'Người dùng ngoài hệ thống'

    @property
    def requester_department(self):
        return self.requester.department if self.requester else ''

    @property
    def requester_username(self):
        return self.requester.username if self.requester else ''

    @property
    def sla_due_at(self):
        from datetime import timedelta
        hours = self.category.sla_hours if self.category else 8
        return self.requested_at + timedelta(hours=hours)

    @property
    def is_sla_met(self):
        endpoint = self.resolved_at or datetime.now()
        return endpoint <= self.sla_due_at

    @property
    def resolution_hours(self):
        if not self.resolved_at:
            return None
        return round((self.resolved_at - self.requested_at).total_seconds() / 3600, 2)


class TicketComment(db.Model):
    __tablename__ = 'ticket_comments'
    id = db.Column(db.Integer, primary_key=True)
    ticket_id = db.Column(db.Integer, db.ForeignKey('tickets.id'), nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    content = db.Column(db.Text, nullable=False)
    is_internal = db.Column(db.Boolean, nullable=False, default=False)
    created_at = db.Column(db.DateTime, default=datetime.now, nullable=False)

    user = db.relationship('User')
    ticket = db.relationship('Ticket', backref=db.backref('comments', lazy=True, order_by='TicketComment.created_at'))


class AuditLog(db.Model):
    __tablename__ = 'audit_logs'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    action = db.Column(db.String(120), nullable=False)
    entity_type = db.Column(db.String(60), nullable=False)
    entity_id = db.Column(db.String(60), default='')
    detail = db.Column(db.Text, default='')
    created_at = db.Column(db.DateTime, default=datetime.now, nullable=False, index=True)

    user = db.relationship('User')


class AppSetting(db.Model):
    __tablename__ = 'app_settings'
    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(100), unique=True, nullable=False)
    value = db.Column(db.Text, default='')


class Asset(db.Model):
    __tablename__ = 'assets'
    id = db.Column(db.Integer, primary_key=True)
    asset_code = db.Column(db.String(80), unique=True, nullable=False, index=True)
    name = db.Column(db.String(180), nullable=False)
    asset_type = db.Column(db.String(120), nullable=False, index=True)
    manufacturer = db.Column(db.String(120), default='')
    model = db.Column(db.String(120), default='')
    serial_number = db.Column(db.String(150), default='', index=True)
    company = db.Column(db.String(150), default='')
    department = db.Column(db.String(150), default='')
    location = db.Column(db.String(180), default='')
    ip_address = db.Column(db.String(64), default='')
    mac_address = db.Column(db.String(64), default='')
    status = db.Column(db.Enum('in_stock', 'in_use', 'repair', 'broken', 'retired', 'disposed'), nullable=False, default='in_stock', index=True)
    condition = db.Column(db.Enum('good', 'fair', 'weak', 'broken'), nullable=False, default='good', index=True)
    assigned_user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True, index=True)
    assigned_to_name = db.Column(db.String(150), default='')
    assigned_at = db.Column(db.DateTime, nullable=True)
    purchase_date = db.Column(db.Date, nullable=True)
    warranty_until = db.Column(db.Date, nullable=True)
    purchase_cost = db.Column(db.Numeric(15, 2), nullable=True)
    supplier = db.Column(db.String(180), default='')
    last_audit_date = db.Column(db.Date, nullable=True)
    note = db.Column(db.Text, default='')
    created_at = db.Column(db.DateTime, default=datetime.now, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now, nullable=False)

    assigned_user = db.relationship('User', foreign_keys=[assigned_user_id], backref='assigned_assets')

    @property
    def assigned_display_name(self):
        if self.assigned_user:
            return self.assigned_user.full_name
        return (self.assigned_to_name or '').strip() or 'Chưa cấp phát'


class AssetHistory(db.Model):
    __tablename__ = 'asset_history'
    id = db.Column(db.Integer, primary_key=True)
    asset_id = db.Column(db.Integer, db.ForeignKey('assets.id'), nullable=False, index=True)
    actor_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    action = db.Column(db.String(60), nullable=False)
    from_value = db.Column(db.String(255), default='')
    to_value = db.Column(db.String(255), default='')
    detail = db.Column(db.Text, default='')
    created_at = db.Column(db.DateTime, default=datetime.now, nullable=False, index=True)

    asset = db.relationship('Asset', backref=db.backref('history', lazy=True, order_by='AssetHistory.created_at.desc()'))
    actor = db.relationship('User')
