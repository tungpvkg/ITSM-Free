from datetime import datetime, timedelta

from models import db, User, Category, Ticket, TicketComment, AuditLog, Asset, AssetHistory


DEMO_PASSWORD = 'Demo@123'
DEMO_ACCOUNTS = [
    ('tech01', 'Nguyễn Minh Khang', 'khang.nguyen@example.local', 'Bộ phận CNTT', 'technical'),
    ('tech02', 'Trần Quốc Huy', 'huy.tran@example.local', 'Bộ phận CNTT', 'technical'),
    ('user01', 'Nguyễn Thị Lan', 'lan.nguyen@example.local', 'Kế toán', 'user'),
    ('user02', 'Lê Hoàng Nam', 'nam.le@example.local', 'Nhân sự', 'user'),
    ('user03', 'Phạm Gia Bảo', 'bao.pham@example.local', 'Kinh doanh', 'user'),
    ('user04', 'Võ Thanh An', 'an.vo@example.local', 'Sản xuất', 'user'),
    ('user05', 'Đặng Mỹ Linh', 'linh.dang@example.local', 'QA/QC', 'user'),
]


def _category(name):
    row = Category.query.filter_by(name=name).first()
    if not row:
        raise RuntimeError(f'Missing demo category: {name}')
    return row


def _dt(base, *, days=0, hours=0, minutes=0):
    return base - timedelta(days=days, hours=hours, minutes=minutes)



def seed_demo_assets(users):
    """Tạo tài sản mẫu cho module Quản lý tài sản CNTT, không tạo trùng."""
    if Asset.query.filter(Asset.asset_code.like('DEMO-ASSET-%')).first():
        return 0
    now = datetime.now().replace(second=0, microsecond=0)
    specs = [
        ('DEMO-ASSET-001', 'Laptop Dell Latitude 5440', 'Laptop', 'Dell', 'Latitude 5440', 'DL5440-NT-001', 'Nhà Máy NT', 'Kế toán', 'VP NT - Kế toán', '', '', 'in_use', 'good', 'user01', 23500000, 420, 20),
        ('DEMO-ASSET-002', 'Laptop HP ProBook 440 G10', 'Laptop', 'HP', 'ProBook 440 G10', 'HP440-NT-002', 'Nhà Máy NT', 'Nhân sự', 'VP NT - Nhân sự', '', '', 'in_use', 'good', 'user02', 21800000, 390, 18),
        ('DEMO-ASSET-003', 'Desktop Dell OptiPlex 7010', 'Desktop', 'Dell', 'OptiPlex 7010', 'OP7010-NT-003', 'Nhà Máy NT', 'Kinh doanh', 'VP NT', '10.10.20.103', '00:11:22:33:44:03', 'in_use', 'good', 'user03', 18500000, 520, 15),
        ('DEMO-ASSET-004', 'Desktop Lenovo ThinkCentre', 'Desktop', 'Lenovo', 'ThinkCentre M70s', 'M70S-NT-004', 'Nhà Máy NT', 'Sản xuất', 'Xưởng sản xuất', '10.10.20.104', '00:11:22:33:44:04', 'in_use', 'fair', 'user04', 17200000, 650, 30),
        ('DEMO-ASSET-005', 'Màn hình Dell 24 inch', 'Monitor', 'Dell', 'P2422H', 'P2422H-NT-005', 'Nhà Máy NT', 'QA/QC', 'Phòng QA/QC', '', '', 'in_use', 'good', 'user05', 4200000, 310, 12),
        ('DEMO-ASSET-006', 'Máy in HP LaserJet Pro', 'Máy in', 'HP', 'LaserJet Pro 4003dn', 'HPLJ-NT-006', 'Nhà Máy NT', 'Kế toán', 'VP NT - Kế toán', '10.10.20.206', '00:11:22:33:44:06', 'in_use', 'good', None, 7800000, 280, 10),
        ('DEMO-ASSET-007', 'Switch Omada PoE 24 Port', 'Switch', 'TP-Link', 'SG3428XMP', 'SG3428-NT-007', 'Nhà Máy NT', 'CNTT', 'Rack mạng NT', '10.10.20.7', '00:11:22:33:44:07', 'in_use', 'good', None, 12800000, 240, 5),
        ('DEMO-ASSET-008', 'Access Point Aruba', 'Access Point', 'Aruba', 'AP21', 'AP21-NT-008', 'Nhà Máy NT', 'CNTT', 'VP NT', '10.10.30.8', '00:11:22:33:44:08', 'in_use', 'good', None, 4800000, 200, 7),
        ('DEMO-ASSET-009', 'Camera IP Dome', 'Camera', 'Hikvision', 'DS-2CD', 'CAM-NT-009', 'Nhà Máy NT', 'CNTT', 'Kho thành phẩm', '10.10.20.209', '00:11:22:33:44:09', 'repair', 'weak', None, 2200000, 900, 45),
        ('DEMO-ASSET-010', 'UPS 1500VA', 'UPS', 'APC', 'SMC1500I', 'UPS-NT-010', 'Nhà Máy NT', 'CNTT', 'Phòng Server', '', '', 'in_use', 'fair', None, 9800000, 1100, 60),
        ('DEMO-ASSET-011', 'Laptop dự phòng', 'Laptop', 'Dell', 'Latitude 3420', 'DL3420-NT-011', 'Nhà Máy NT', 'CNTT', 'Kho IT', '', '', 'in_stock', 'good', None, 16500000, 700, 21),
        ('DEMO-ASSET-012', 'Màn hình 22 inch cũ', 'Monitor', 'Samsung', 'S22F350', 'SS22-NT-012', 'Nhà Máy NT', 'CNTT', 'Kho IT', '', '', 'broken', 'broken', None, 2900000, 1800, 180),
        ('DEMO-ASSET-013', 'NAS Backup', 'NAS', 'Synology', 'DS923+', 'NAS-NT-013', 'Nhà Máy NT', 'CNTT', 'Phòng Server', '10.10.20.19', '00:11:22:33:44:13', 'in_use', 'good', None, 24500000, 160, 3),
        ('DEMO-ASSET-014', 'Mini PC phòng họp', 'Desktop', 'Intel', 'NUC i5', 'NUC-NT-014', 'Nhà Máy NT', 'Hành chính', 'Phòng họp', '10.10.20.114', '00:11:22:33:44:14', 'in_use', 'good', None, 14200000, 360, 14),
        ('DEMO-ASSET-015', 'Điện thoại công ty', 'Điện thoại', 'Samsung', 'Galaxy A55', 'A55-NT-015', 'Nhà Máy NT', 'Kinh doanh', 'VP NT', '', '', 'retired', 'weak', None, 8900000, 760, 90),
    ]
    created = 0
    for code, name, asset_type, manufacturer, model, serial, company, department, location, ip, mac, status, condition, user_key, cost, purchase_days, audit_days in specs:
        user = users.get(user_key) if user_key else None
        a = Asset(
            asset_code=code, name=name, asset_type=asset_type, manufacturer=manufacturer, model=model,
            serial_number=serial, company=company, department=department, location=location,
            ip_address=ip, mac_address=mac, status=status, condition=condition,
            assigned_user_id=user.id if user else None,
            assigned_at=(now - timedelta(days=90)) if user else None,
            purchase_date=(now - timedelta(days=purchase_days)).date(),
            warranty_until=(now + timedelta(days=max(0, 1095-purchase_days))).date() if purchase_days < 1095 else None,
            purchase_cost=cost, supplier='Nhà cung cấp demo',
            last_audit_date=(now - timedelta(days=audit_days)).date(),
            note='Dữ liệu demo module Quản lý tài sản CNTT.'
        )
        db.session.add(a); db.session.flush(); created += 1
        db.session.add(AssetHistory(
            asset_id=a.id, actor_id=None, action='demo_create', from_value='',
            to_value=f'{a.asset_code}; {a.status}; {a.assigned_display_name}',
            detail='Khởi tạo tài sản mẫu khi cài chế độ Demo.', created_at=a.created_at
        ))
        if user:
            db.session.add(AssetHistory(
                asset_id=a.id, actor_id=None, action='assign', from_value='Trong kho',
                to_value=user.full_name, detail='Cấp phát mẫu cho người dùng.', created_at=a.assigned_at
            ))
    return created

def seed_demo_data():
    """Tạo bộ dữ liệu mẫu đầy đủ để trình diễn Dashboard/Báo cáo.

    Hàm có tính idempotent: nếu các tài khoản/ticket demo đã tồn tại thì không
    tạo trùng. Không tạo Admin demo; Admin đầu tiên vẫn do bộ cài yêu cầu nhập.
    """
    users = {}
    for username, full_name, email, department, role in DEMO_ACCOUNTS:
        user = User.query.filter_by(username=username).first()
        if not user:
            user = User(
                username=username,
                full_name=full_name,
                email=email,
                department=department,
                role=role,
                is_active=True,
            )
            user.set_password(DEMO_PASSWORD)
            db.session.add(user)
            db.session.flush()
        users[username] = user

    # Nếu ticket demo đã có, vẫn đảm bảo dữ liệu mẫu của các module mới được bổ sung.
    if Ticket.query.filter(Ticket.code.like('DEMO-%')).first():
        asset_count = seed_demo_assets(users)
        db.session.commit()
        return {'users': len(users), 'tickets': 0, 'assets': asset_count, 'existing': True}

    now = datetime.now().replace(second=0, microsecond=0)
    categories = {
        'pc': _category('Sự cố máy tính / Laptop'),
        'internet': _category('Không truy cập Internet / Wi-Fi'),
        'lan': _category('Mạng LAN chậm / mất kết nối'),
        'printer': _category('Không in được / lỗi máy in'),
        'm365': _category('Email / Microsoft 365 / Teams'),
        'password': _category('Quên mật khẩu / khóa tài khoản'),
        'software': _category('Cài đặt phần mềm'),
        'malware': _category('Virus / nghi ngờ mã độc'),
        'internal': _category('Không truy cập phần mềm nội bộ'),
        'access': _category('Yêu cầu cấp quyền truy cập'),
        'device': _category('Yêu cầu cấp mới thiết bị CNTT'),
        'camera': _category('Camera / CCTV'),
        'mobile': _category('Điện thoại / thiết bị di động'),
        'vpn': _category('VPN / làm việc từ xa'),
        'other': _category('Khác'),
    }

    specs = [
        # requester, category, subject, description, priority, status, assignee, requested_at
        ('user01', 'pc', 'Máy tính không khởi động được Windows', 'Máy kế toán bật nguồn nhưng dừng ở màn hình logo, cần IT kiểm tra.', 'high', 'new', None, _dt(now, hours=1, minutes=15)),
        ('user02', 'lan', 'Mạng LAN phòng Nhân sự chập chờn', 'Các máy trong phòng bị mất kết nối nội bộ theo từng đợt ngắn.', 'high', 'assigned', 'tech01', _dt(now, hours=3, minutes=20)),
        ('user03', 'malware', 'Nghi ngờ máy tính nhiễm mã độc', 'Trình duyệt tự mở quảng cáo và máy chạy chậm bất thường.', 'critical', 'in_progress', 'tech02', _dt(now, hours=5, minutes=5)),
        ('user04', 'm365', 'Không đăng nhập được Microsoft Teams', 'Teams yêu cầu xác thực lại liên tục, người dùng không vào được cuộc họp.', 'medium', 'waiting_user', 'tech01', _dt(now, hours=7, minutes=30)),
        ('user01', 'printer', 'Máy in kế toán báo Offline', 'Không in được chứng từ từ hai máy trong phòng Kế toán.', 'medium', 'resolved', 'tech02', _dt(now, hours=2, minutes=10)),
        ('user02', 'software', 'Cài phần mềm đọc PDF cho máy mới', 'Cần cài phần mềm PDF và đặt ứng dụng mặc định.', 'low', 'closed', 'tech01', _dt(now, days=1, hours=3)),
        ('user03', 'vpn', 'VPN làm việc từ xa không kết nối', 'Client VPN báo timeout khi kết nối từ mạng ngoài công ty.', 'high', 'closed', 'tech02', _dt(now, days=2, hours=2)),
        (None, 'camera', 'Camera kho thành phẩm mất hình', 'Người dùng ngoài hệ thống báo camera khu vực cửa kho không có tín hiệu.', 'high', 'resolved', 'tech01', _dt(now, hours=1, minutes=40)),
        ('user05', 'access', 'Cấp quyền thư mục dùng chung QA', 'Cần quyền đọc/ghi thư mục báo cáo chất lượng của bộ phận QA/QC.', 'medium', 'new', None, _dt(now, days=1, minutes=40)),
        ('user04', 'internal', 'Không vào được phần mềm sản xuất', 'Phần mềm nội bộ báo không kết nối được máy chủ dữ liệu.', 'medium', 'in_progress', 'tech02', _dt(now, days=1, hours=5)),
        ('user01', 'internet', 'Mất Internet khu vực văn phòng', 'Nhiều máy cùng mất Internet nhưng vẫn truy cập được một số tài nguyên LAN.', 'critical', 'closed', 'tech01', _dt(now, days=3, hours=7)),
        ('user02', 'mobile', 'Điện thoại công ty không đồng bộ Email', 'Ứng dụng Outlook trên điện thoại không cập nhật thư mới.', 'low', 'assigned', 'tech02', _dt(now, days=2, hours=4)),
        ('user03', 'm365', 'Outlook liên tục hỏi mật khẩu', 'Outlook desktop hiện hộp thoại nhập mật khẩu sau khi đổi password.', 'high', 'waiting_user', 'tech01', _dt(now, days=4, hours=2)),
        ('user05', 'password', 'Tài khoản Windows bị khóa', 'Người dùng nhập sai mật khẩu nhiều lần và không đăng nhập được.', 'low', 'resolved', 'tech02', _dt(now, minutes=55)),
        ('user04', 'pc', 'Laptop chạy chậm sau cập nhật', 'Máy mất nhiều thời gian khi đăng nhập và mở ứng dụng văn phòng.', 'medium', 'closed', 'tech01', _dt(now, days=6, hours=3)),
        ('user05', 'device', 'Đề nghị cấp thêm màn hình làm việc', 'Cần màn hình phụ để theo dõi biểu mẫu kiểm tra chất lượng.', 'medium', 'new', None, _dt(now, days=2, hours=1)),
        ('user03', 'lan', 'Kết nối mạng tại phòng họp bị chậm', 'Sao chép file nội bộ chậm rõ rệt khi dùng cổng mạng bàn họp.', 'high', 'in_progress', 'tech02', _dt(now, days=7, hours=2)),
        ('user04', 'camera', 'Camera khu vực đóng gói bị mờ', 'Hình ảnh ban đêm mờ, khó nhận diện chi tiết.', 'medium', 'closed', 'tech01', _dt(now, days=8, hours=4)),
        ('user01', 'other', 'Kiểm tra cáp HDMI phòng họp', 'Màn hình phòng họp đôi lúc không nhận tín hiệu từ mini PC.', 'low', 'assigned', 'tech02', _dt(now, days=9, hours=1)),
        ('user05', 'internet', 'Wi-Fi QA kết nối nhưng không ra Internet', 'Thiết bị nhận IP nhưng truy cập web không được.', 'high', 'closed', 'tech02', _dt(now, days=11, hours=2)),
    ]

    created = []
    for idx, (requester_key, cat_key, subject, description, priority, status, assignee_key, requested_at) in enumerate(specs, 1):
        t = Ticket(
            code=f'DEMO-{idx:04d}',
            requester_id=users[requester_key].id if requester_key else None,
            requester_name='Trần Văn Minh - Kho thành phẩm' if requester_key is None else '',
            assignee_id=users[assignee_key].id if assignee_key else None,
            category_id=categories[cat_key].id,
            subject=subject,
            description=description,
            priority=priority,
            status=status,
            requested_at=requested_at,
        )

        if status in ('assigned', 'in_progress', 'waiting_user', 'resolved', 'closed'):
            t.first_response_at = min(requested_at + timedelta(minutes=25), now - timedelta(minutes=1))
        if status in ('resolved', 'closed'):
            # Ticket resolved giữ trong khoảng auto-close 30 phút để bản demo vẫn thấy trạng thái Đã hoàn thành.
            if status == 'resolved':
                t.resolved_at = now - timedelta(minutes=10 if idx % 2 else 20)
            else:
                t.resolved_at = requested_at + timedelta(hours=2 + (idx % 4))
                t.closed_at = t.resolved_at + timedelta(minutes=30)
            t.resolution = {
                'printer': 'Khởi động lại Print Spooler, kiểm tra kết nối và đưa máy in về trạng thái Online.',
                'vpn': 'Cập nhật cấu hình VPN client và kiểm tra lại kết nối từ mạng ngoài.',
                'camera': 'Kiểm tra nguồn/kết nối camera và xác nhận hình ảnh đã ổn định.',
                'internet': 'Kiểm tra uplink, làm mới kết nối và xác nhận người dùng truy cập Internet bình thường.',
                'password': 'Mở khóa tài khoản và hướng dẫn người dùng đăng nhập lại.',
            }.get(cat_key, 'Đã kiểm tra, xử lý và xác nhận dịch vụ hoạt động bình thường.')

        db.session.add(t)
        db.session.flush()
        created.append(t)

        actor = users.get(assignee_key) or users.get(requester_key)
        db.session.add(AuditLog(
            user_id=users[requester_key].id if requester_key else None,
            action='demo_create_ticket',
            entity_type='ticket',
            entity_id=str(t.id),
            detail=f'Dữ liệu demo tạo {t.code}: {t.subject}',
            created_at=requested_at,
        ))
        if assignee_key:
            db.session.add(AuditLog(
                user_id=actor.id,
                action='demo_assign_ticket',
                entity_type='ticket',
                entity_id=str(t.id),
                detail=f'Dữ liệu demo phân công {t.code} cho {actor.full_name}',
                created_at=t.first_response_at or requested_at,
            ))

    # Trao đổi mẫu để trang chi tiết ticket có dữ liệu thực tế.
    comment_specs = [
        (2, 'tech01', 'Đã tiếp nhận. Tôi đang kiểm tra switch và cổng mạng tại khu vực Nhân sự.', True),
        (2, 'user02', 'Hiện tượng xảy ra nhiều nhất vào đầu giờ chiều.', False),
        (3, 'tech02', 'Đã cô lập máy khỏi mạng để kiểm tra an toàn trước khi xử lý.', True),
        (4, 'tech01', 'Vui lòng thử đăng nhập Teams trên trình duyệt và phản hồi kết quả.', False),
        (5, 'tech02', 'Đã xử lý dịch vụ in. Nhờ anh/chị in thử một chứng từ để xác nhận.', False),
        (8, 'tech01', 'Đã kiểm tra camera và nguồn cấp. Hình ảnh hiện đã trở lại.', False),
        (10, 'tech02', 'Đang kiểm tra kết nối từ máy trạm đến máy chủ ứng dụng.', True),
        (13, 'tech01', 'Đã hướng dẫn xóa thông tin đăng nhập cũ. Chờ người dùng xác nhận.', False),
        (17, 'tech02', 'Đã đo thử kết nối tại phòng họp, tiếp tục kiểm tra patch panel.', True),
        (19, 'tech02', 'Đã nhận yêu cầu, sẽ kiểm tra cáp HDMI và cổng xuất hình.', False),
    ]
    for ticket_no, username, content, is_internal in comment_specs:
        t = created[ticket_no - 1]
        u = users[username]
        db.session.add(TicketComment(
            ticket_id=t.id,
            user_id=u.id,
            content=content,
            is_internal=is_internal,
            created_at=min(t.requested_at + timedelta(minutes=35), now),
        ))

    asset_count = seed_demo_assets(users)
    db.session.commit()
    return {'users': len(users), 'tickets': len(created), 'assets': asset_count, 'existing': False}
