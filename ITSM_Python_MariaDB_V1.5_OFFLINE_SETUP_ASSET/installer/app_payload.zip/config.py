import os
from urllib.parse import quote_plus
from dotenv import load_dotenv

load_dotenv()


class Config:
    SECRET_KEY = os.getenv('SECRET_KEY', 'CHANGE_ME_ITSMPRO_SECRET')
    DB_HOST = os.getenv('DB_HOST', '127.0.0.1')
    DB_PORT = int(os.getenv('DB_PORT', '3306'))
    DB_NAME = os.getenv('DB_NAME', 'itsm_db')
    DB_USER = os.getenv('DB_USER', 'itsm_app')
    DB_PASSWORD = os.getenv('DB_PASSWORD', '')

    # URL-encode user/password để mật khẩu có @, #, :, /... vẫn kết nối đúng.
    _DB_USER_Q = quote_plus(DB_USER)
    _DB_PASSWORD_Q = quote_plus(DB_PASSWORD)
    SQLALCHEMY_DATABASE_URI = (
        f"mysql+pymysql://{_DB_USER_Q}:{_DB_PASSWORD_Q}@{DB_HOST}:{DB_PORT}/{DB_NAME}?charset=utf8mb4"
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {
        'pool_pre_ping': True,
        'pool_recycle': 280,
    }
    APP_HOST = os.getenv('APP_HOST', '0.0.0.0')
    APP_PORT = int(os.getenv('APP_PORT', '8088'))
    APP_DEBUG = os.getenv('APP_DEBUG', '0') == '1'
