(function(){
  function prep(id){
    const c=document.getElementById(id); if(!c) return null;
    const ratio=window.devicePixelRatio||1, rect=c.getBoundingClientRect();
    const w=Math.max(360,Math.floor(rect.width||700)), h=Math.max(240,Math.floor(parseInt(c.getAttribute('height')||280)));
    c.width=w*ratio;c.height=h*ratio;c.style.width=w+'px';c.style.height=h+'px';
    const x=c.getContext('2d');x.scale(ratio,ratio);x.font='12px Segoe UI, Arial';return {c,x,w,h};
  }
  function clear(x,w,h){x.clearRect(0,0,w,h);x.fillStyle='#ffffff';x.fillRect(0,0,w,h)}
  function bar(id,labels,data){
    const p=prep(id); if(!p)return; const {x,w,h}=p; clear(x,w,h);
    const max=Math.max(1,...data), left=46,right=18,top=20,bottom=70, cw=w-left-right,ch=h-top-bottom;
    x.strokeStyle='#d0d5dd';x.fillStyle='#667085';x.lineWidth=1;
    for(let i=0;i<=4;i++){const y=top+ch-(ch*i/4);x.beginPath();x.moveTo(left,y);x.lineTo(w-right,y);x.stroke();x.fillText(String(Math.round(max*i/4)),8,y+4)}
    const slot=cw/Math.max(1,data.length), bw=Math.max(10,Math.min(46,slot*.62));
    data.forEach((v,i)=>{const bh=ch*(v/max), bx=left+i*slot+(slot-bw)/2, by=top+ch-bh;x.fillStyle='#155eef';x.fillRect(bx,by,bw,bh);x.fillStyle='#344054';x.fillText(String(v),bx+Math.max(0,bw/2-5),Math.max(12,by-5));x.save();x.translate(bx+bw/2,h-bottom+12);x.rotate(-.45);x.textAlign='right';x.fillText(labels[i]||'',0,0);x.restore();});
  }
  function line(id,labels,data){
    const p=prep(id); if(!p)return; const {x,w,h}=p; clear(x,w,h);
    const max=Math.max(1,...data), left=46,right=18,top=20,bottom=48,cw=w-left-right,ch=h-top-bottom;
    x.strokeStyle='#d0d5dd';x.fillStyle='#667085';
    for(let i=0;i<=4;i++){const y=top+ch-(ch*i/4);x.beginPath();x.moveTo(left,y);x.lineTo(w-right,y);x.stroke();x.fillText(String(Math.round(max*i/4)),8,y+4)}
    if(!data.length)return; x.strokeStyle='#155eef';x.lineWidth=3;x.beginPath();
    data.forEach((v,i)=>{const px=left+(data.length===1?cw/2:cw*i/(data.length-1)),py=top+ch-(ch*v/max);if(i===0)x.moveTo(px,py);else x.lineTo(px,py)});x.stroke();
    data.forEach((v,i)=>{const px=left+(data.length===1?cw/2:cw*i/(data.length-1)),py=top+ch-(ch*v/max);x.fillStyle='#155eef';x.beginPath();x.arc(px,py,4,0,Math.PI*2);x.fill();x.fillStyle='#475467';x.textAlign='center';if(i%Math.ceil(data.length/10||1)===0)x.fillText(labels[i]||'',px,h-14)});
  }
  window.ITSMChart={bar,line};
})();
