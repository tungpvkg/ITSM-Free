import os
import sys

from sqlalchemy import inspect, text

from app import app
from models import db, Category, AppSetting
from seed_demo import seed_demo_data, DEMO_PASSWORD


def migrate_database():
    """Nang cap schema cu len schema hien tai ma khong xoa du lieu."""
    inspector = inspect(db.engine)
    tables = set(inspector.get_table_names())
    if 'tickets' not in tables:
        return

    columns = {c['name']: c for c in inspector.get_columns('tickets')}
    with db.engine.begin() as conn:
        if 'requester_name' not in columns:
            conn.execute(text(
                "ALTER TABLE tickets ADD COLUMN requester_name VARCHAR(150) NULL AFTER requester_id"
            ))
            print('[MIGRATION] Added requester_name.')

        requester_col = columns.get('requester_id')
        if requester_col and not requester_col.get('nullable', True):
            conn.execute(text(
                "ALTER TABLE tickets MODIFY COLUMN requester_id INT NULL"
            ))
            print('[MIGRATION] requester_id is now nullable.')


def resolve_data_mode():
    if '--demo' in sys.argv:
        return 'demo'
    if '--clean' in sys.argv:
        return 'clean'
    mode = os.environ.get('ITSM_DATA_MODE', 'clean').strip().lower()
    return 'demo' if mode == 'demo' else 'clean'


def main():
    try:
        with app.app_context():
            db.create_all()
            migrate_database()

            defaults = [
                ('Sự cố máy tính / Laptop', 8),
                ('Không truy cập Internet / Wi-Fi', 4),
                ('Mạng LAN chậm / mất kết nối', 4),
                ('Không in được / lỗi máy in', 8),
                ('Email / Microsoft 365 / Teams', 8),
                ('Quên mật khẩu / khóa tài khoản', 4),
                ('Cài đặt phần mềm', 16),
                ('Virus / nghi ngờ mã độc', 2),
                ('Không truy cập phần mềm nội bộ', 4),
                ('Yêu cầu cấp quyền truy cập', 16),
                ('Yêu cầu cấp mới thiết bị CNTT', 24),
                ('Camera / CCTV', 8),
                ('Điện thoại / thiết bị di động', 8),
                ('VPN / làm việc từ xa', 4),
                ('Khác', 8),
            ]
            for name, sla in defaults:
                if not Category.query.filter_by(name=name).first():
                    db.session.add(Category(name=name, sla_hours=sla))

            settings = {
                'company_name': 'IT Service Management',
                'support_name': 'Bộ phận CNTT',
                'default_sla_hours': '8',
                'auto_close_minutes': '30',
            }
            for key, value in settings.items():
                if not AppSetting.query.filter_by(key=key).first():
                    db.session.add(AppSetting(key=key, value=value))

            db.session.commit()

            mode = resolve_data_mode()
            if mode == 'demo':
                result = seed_demo_data()
                print(f"[DEMO] Seeded demo data: {result['users']} users, {result['tickets']} tickets, {result.get('assets', 0)} assets.")
                print(f'[DEMO] Password for tech01/tech02/user01..user05: {DEMO_PASSWORD}')
            else:
                print('[CLEAN] No demo users/tickets created.')
    except Exception as exc:
        print('[ERROR] ITSM database initialization failed.')
        print(str(exc))
        return 1

    print(f'OK: ITSM MariaDB schema/default settings ready - V1.4 ({resolve_data_mode()}).')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
