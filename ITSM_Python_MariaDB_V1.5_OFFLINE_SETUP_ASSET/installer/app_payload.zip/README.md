# ITSM Python + MariaDB

**Hệ Thống ITSM - Phát Triển Và Chia Sẽ Miễn Phí Bởi Phạm Việt Tùng**

Hệ thống IT Service Management / Helpdesk nội bộ viết bằng Flask (Python) và MariaDB.

## Chức năng

- 3 quyền: **Admin / Technical / User**.
- User: đăng nhập, tạo ticket, chọn nhóm hỗ trợ CNTT phổ thông, mức ưu tiên, mô tả sự cố, theo dõi trạng thái và trao đổi với IT.
- Technical: xem dashboard, tiếp nhận ticket, cập nhật trạng thái/ưu tiên, ghi chú nội bộ, phản hồi user, nhập kết quả xử lý.
- Admin: toàn quyền Technical + phân công ticket, tạo/sửa/khóa/xóa tài khoản, đổi mật khẩu, đổi quyền, cấu hình danh mục và SLA.
- Admin/Technical có thể tạo yêu cầu hộ User có trong hệ thống hoặc người dùng ngoài hệ thống.
- Ticket **Đã hoàn thành** tự chuyển sang **Đã đóng** theo thời gian do Admin cấu hình (mặc định 30 phút).
- Báo cáo: KPI, SLA, thời gian xử lý, phản hồi đầu, biểu đồ và xuất Excel.
- Audit Log trong MariaDB để truy vết thao tác.

## Dữ liệu ban đầu khi cài đặt

Bộ cài One-Click có 2 lựa chọn:

1. **Dữ liệu sạch**: chỉ tạo schema, danh mục hỗ trợ và cấu hình mặc định. Không tạo User/Technical/Ticket mẫu.
2. **Dữ liệu demo**: ngoài danh mục/cấu hình còn tạo đầy đủ dữ liệu trình diễn cho Dashboard/Báo cáo:
   - Technical: `tech01`, `tech02`
   - User: `user01` đến `user05`
   - Mật khẩu chung dữ liệu demo: `Demo@123`
   - 20 ticket mẫu đủ mức ưu tiên và trạng thái
   - Ticket tạo hộ/người dùng ngoài hệ thống
   - Phản hồi, ghi chú nội bộ và Audit Log mẫu

**Admin đầu tiên luôn do người cài tự nhập trong quá trình Setup**, kể cả khi chọn dữ liệu demo.

## Chạy `setup_db.py` thủ công

- Chỉ tạo/nâng cấp schema và dữ liệu mặc định: `python setup_db.py --clean`
- Bổ sung dữ liệu demo: `python setup_db.py --demo`

`setup_db.py` không tự xóa database đang có. Việc xóa/tạo sạch database được bộ One-Click Setup xử lý với bước xác nhận riêng.

## Truy cập

- Trên máy cài: `http://127.0.0.1:8088`
- Máy khác trong LAN: `http://IP-MAY-CHU:8088`

## Database

- DB mặc định: `itsm_db`
- User ứng dụng mặc định: `itsm_app`
- Charset: `utf8mb4`
- Các bảng chính: `users`, `categories`, `tickets`, `ticket_comments`, `audit_logs`, `app_settings`.

## Khuyến nghị triển khai

- Không dùng tài khoản MariaDB root cho ứng dụng.
- Dữ liệu demo chỉ dùng để thử nghiệm/trình diễn; khi triển khai thật nên chọn **Dữ liệu sạch**.
- Nếu đã dùng dữ liệu demo, nên đổi/xóa các tài khoản mẫu trước khi đưa vào vận hành thật.
- Đặt sau reverse proxy HTTPS nếu public ra ngoài LAN.
- Backup MariaDB định kỳ.

## Cập nhật V1.4 R2

- Thêm dấu ấn cá nhân trên giao diện đăng nhập và toàn bộ trang sau đăng nhập.
- Thêm lựa chọn **Dữ liệu sạch / Dữ liệu demo** ngay trong One-Click Setup.
- Thêm `seed_demo.py` chứa toàn bộ dữ liệu demo trong source.
- Dữ liệu demo có Technical/User, 20 ticket, phản hồi, ghi chú nội bộ và Audit Log.
- Giữ nguyên cơ chế tự tạo Admin đầu tiên để đảm bảo không có Admin mặc định.


## Cập nhật V1.5 - Quản lý tài sản CNTT

- Menu **Tài sản CNTT** dành cho Admin và Technical.
- Quản lý mã tài sản, loại thiết bị, hãng/model/serial, công ty, phòng ban, vị trí, IP/MAC.
- Theo dõi trạng thái, tình trạng, người sử dụng, ngày mua, bảo hành, giá trị, nhà cung cấp và ngày audit.
- Cấp phát/thu hồi tài sản, lưu lịch sử thao tác.
- Xuất Excel danh sách tài sản.
- Chỉ Admin được xóa tài sản; Admin/Technical được thêm, sửa, cấp phát và thu hồi.
- Khi cài ở chế độ Demo, hệ thống tạo thêm 15 tài sản mẫu.
